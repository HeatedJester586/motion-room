# Generated distribution copy. Matching readable GPL source is bundled in source/.
import base64 as _sfm_b64, zlib as _sfm_zlib
exec(compile(_sfm_zlib.decompress(_sfm_b64.b85decode(b'c-obcO-sZu5Qgvh6+<s=p~gK69z4h*xUPucL8PRcX&Y=aAxXFR?@h8_E~^J~N@nJrndfb@EPL${R^%0Fcp(~LppGhVJ<S@F1|QOIN=uqyL_LAfGR1_HS3zPdwrEjr(D5wGSZhNIBYZ!o2GnTCdUy^`#`cfKd@=U8UasLbC5pOk)qr(faw9?`57&^Z4QZFh+n6@1ZP<((-Q}zf6SoRy7xYi0kufH*g{UaX8wTNIJE#bfyOaSXp(UH{^;QfMLb0eoQ;JkD_ZVtCY=qY2gHp&c;ly^`K#dsSI5-7W8%ek@hBspK*;$%`F=0g1M?9`v0y``fk3~OO4U0pE6N_>Q=2Uuei%(t+j-O4B=cf^uWnAN2l$XUkvK4vqCVXXYi@0oALH@A1Ti)k8$$rtJ>U}5p;K@KG_oh$UVyB!(d!YQwt25GQ(SK=wA+$Ks7K>x+@>grpKk^MiBkdd')), __file__, "exec"), globals(), globals())
del _sfm_b64, _sfm_zlib
