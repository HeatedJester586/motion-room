<p align="center"><img src="docs/brand/motion_room_logo.png" alt="Motion Room" width="180"></p>

# Motion Room — Blender add-on 0.9.30

**Animate in Blender with Source Filmmaker's mechanics.** The Motion Room
tab follows SFM's rules for selecting controls, choosing time, posing through a
floating edit, presets, Graph keys, locks and puppeteering. Blender supplies the
rendering, scene, editors, workspace system and animation storage: every
result is ordinary Blender keys. Works in Blender 4.0 and later; tested on
4.0.2, 4.2.23, 4.4.3, 5.0.1, 5.1.2 and 5.2.2 (Windows).

The exact rules (what each action changes, over which time, and what Enter,
Esc, selection changes, saving and undo do) are in
[docs/ANIMATION_CONTRACT.md](docs/ANIMATION_CONTRACT.md). How each rule was
verified is in [VALIDATION.md](VALIDATION.md), and what matches SFM and what
does not is in [docs/SFM_COVERAGE.md](docs/SFM_COVERAGE.md).

## Try it

Version 0.9.40 adds a **Tools** button on the Timeline ribbon. **Drag Sliders**:
click Scale Motion, Scale from Frame, Push / Pull, Connect Endpoints, Stitch to
Previous, Tangents to Linear or Match Cycle Tangents, move the mouse left or
right, click to keep, Esc to cancel. They work on the red Time Slider range, or
the whole playback range. **Pose**: one click for Mirror, Mirror Range, Opposite
and Align. Rigs whose bone names do not say their side use **Build Mirror Table**,
which pairs bones by rest position. **Temp Pivot**: At Selection, At Active or
Click to Place, then rotate or scale around it; Off puts the Transform Pivot and
3D Cursor back. It adds no object, constraint or key. Mirror now uses the pose on
screen, keyed or not; it used to throw away an unkeyed pose.

Version 0.9.39 fixes tools under Tween > Curve and Timing Tools: **Share Key
Times** no longer adds keys at the range ends or changes the motion, **Simplify**
only removes keys, **Crop** keeps the pose at its edges and **Bake** uses your
Keymode. Baking temporary controls removes the helper and has a **Keys Only**
option, and Mirror across the range keeps your key times.

Version 0.9.38 adds **Always Bones**: on keeps the native Bones overlay visible,
off returns to holding Ctrl to reveal controls. Changes to Blender's native
Bones overlay also update that mode. **In Front** is a separate button bound
directly to the active rig's native In Front checkbox (through-mesh drawing).
Holding Ctrl still temporarily enables In Front, restoring its prior state
when released. The visibility choice is remembered with workspace settings.

Motion and Graph now put Auto Key, Layers/Tween/Driven Key, Motion Paths,
Onion Skin, bone display and Inherit Rotation on their bottom toolbar. Curve
editing (Focus, tangents, Offset, Keymode, Buffer) remains at the top. With a
Maya slider underneath, its row supplies playback/range controls once, while
the timeline footer holds animation/display tools. Older releases without
footer support, and Blender Timeline mode, use the header fallback.

Version 0.9.37 hides the Maya Time Slider in Clip mode. Clip keeps its own
playback buttons. Leaving Clip restores the slider at its saved height if it
was visible before entering Clip; a manually hidden slider remains hidden.
The Time Slider toggle is disabled in Clip. Native area changes happen on the
idle timer rather than while a tab button is drawing/processing an event.

Version 0.9.36 keeps Clip playback controls in the Clip header, immediately
after the timeline mode buttons. An adjacent Maya slider uses that shared row
instead of drawing duplicate buttons. Hiding the slider leaves Clip controls
available; hiding the Clip header gives the slider its own controls again.
Motion and Graph footer behavior is unchanged.

Version 0.9.35 fixes five library edge cases found by the feature audit:
poses now include unkeyed rig sliders and shape keys; quaternion pose blending
uses consistent signs and normalization; animation insertion shifts channels by
one shared clip duration; recovery restores all keys of the recorded channels;
and ambiguous multi-object mappings refuse instead of collapsing objects.
Rotation-mode/array-size mismatches and malformed payloads also refuse. Poses
omit inactive rotation representations left behind after a rotation-mode change.
Recovery restores recorded channels only, not arbitrary additions elsewhere in
the scene. Name-based transfer assumes compatible rigs; it does not retarget
arbitrary skeletons. Live UI/undo and broad rig compatibility remain unverified.

Version 0.9.34 reduces all-control drag overhead: Graph pose edits share the
parent-space evaluation instead of re-evaluating the scene per selected bone;
IDs are tagged once per rig/Action; translation-only Motion edits skip rotation
sampling; restored baseline snapshots are reused. Bonnie's 73-bone background
diagnostic improved an all-bone Graph edit from about 102 ms to 21 ms. This is
CPU/API latency, not measured viewport FPS. Motion range edits remain heavier.
Also fixes the temporary-controls target picker: Blender operators cannot own
ID PointerProperties, so it now uses an object-name search field.

Version 0.9.33 implements the remaining animator-toolkit families under the
existing **Tween** dropdown, without adding ribbon buttons:

- **Pose and Animation Library**: named scene-persistent poses and animation,
  JSON import/export, name mappings, pose blending, animation insert/replace,
  preferred default pose, and manual animation recovery snapshots.
- **Mirror / Align / World Blend**: mirror poses or the animation range,
  opposite selection, saved symmetry names, blend toward a reference world pose,
  hold world poses, align to the active control, copy/paste relative transform
  relationships. Auto Mirror is opt-in for the active control in Motion Room.
- **Temporary Controls and Pivots**: sampled world controls, FK helper chains,
  cursor pivots, aim targets, keyed grab/release to object/camera spaces, bake
  and detach, and safe cleanup of unused selected helpers.
- **Compensated Rig Space Switch**: key a numeric rig custom property while
  preserving that control's world pose. Unsupported/partial constraints refuse
  rather than silently changing the pose. This is not automatic IK/FK retargeting.
- **Curve and Timing Tools**: the earlier shaping/timing tools plus segment
  stitching, cycle tangent matching, Euler continuity filtering, key-time sharing,
  sampled simplification, cycle extension/cropping and a master-curve link.
  Capture a reference curve in Graph, edit it normally, then Apply Changes to
  propagate its difference to the captured target curves. Clear Link keeps the result.
- **Blend to Default / Buffer**: drag from the starting keyed pose toward RNA
  defaults, a preferred library pose or saved buffer curves.
- **Motion Paths gear**: rotation-speed and acceleration coloring, plus evaluated
  mesh vertex tracking. Vertex indices require stable topology and are display-only.

Transforms use compatible control names/rest setups or explicit mappings;
this is not arbitrary skeleton retargeting. Temporary controls sample the scene
animation range, with limits on total work. Scalar/Euler curve shaping and
master links do not operate on quaternion components; use pose blending instead.
Simplification is measured on quarter-frame samples, not an exact continuous
curve guarantee. Euler filtering can remove intentional full turns. Buffer
blending uses the existing buffer evaluator (native easing types are approximated).
New tools received targeted background checks; the full live UI/undo test suite
was not run, per the request to avoid opening test windows.

Version 0.9.32 adds **Tween > Curve and Timing Tools**, with no extra ribbon
buttons. Select controls, choose an operation, set the frame range and amount,
then confirm: Scale Motion (around the average), Scale from Reference Frame,
Push/Pull (deviation from the endpoint line), Connect Endpoints, Blend Tangents
to Linear, Nudge Keys, Ordered Stagger, Insert Time and Bake at Interval.
The red Time Slider selection supplies the initial range, otherwise playback
range is used. Insert Time starts at the playhead. Nudge/Stagger refuse key
collisions. Bake samples the original curves and uses linear interpolation
between samples; it does not promise exact continuous curve preservation.
Scalar/Euler shaping is supported; use Tween for quaternion pose blends.
This is another subset of the roadmap, not the complete remaining toolkit.

Version 0.9.31 begins the staged animator toolkit: the **Tween** dropdown
now includes **Blend to Frame**, **Blend to Previous** and **Blend to Next**.
Set the reference frame (the clock button uses the playhead), then drag a
blend button left/right and click to keep it; Escape restores all keys and
handles. 0% keeps the starting keyed pose; 100% reaches the target. Negative
amounts and overshoot are supported. Operations edit the active layer's curve
values. World-space solving and default/buffer/mirror targets are future work.
Quaternion blends handle equivalent opposite-sign rotations safely and skip
incomplete locked rotation groups. The complete staged scope is in
[docs/ANIMATOR_TOOLKIT_ROADMAP.md](docs/ANIMATOR_TOOLKIT_ROADMAP.md).

Version 0.9.30 fixes Motion Room crashing Blender 4.4 at start (4.4 crashes
writing a workspace to a file). Blender 4.4 and 5.0 cannot save workspaces
(5.0 writes the file without one), so on those two versions a custom window
layout and tab position are not remembered between sessions; every setting
still is.

Version 0.9.28: the Blender Timeline and Clip Editor modes have the play
buttons too when the Time Slider is hidden (at the start of their header:
Blender keeps a bottom bar closed in those editors). In the work-camera menu,
**Fly Up / Down** chooses SFM's Z / X or Blender's E / Q (0.9.29: one pair
only, never both; SFM by default), and the
handles setting is now **Handles (W / E)**, showing the keys you have set.

Version 0.9.27 also merges the playback controls: with the Time Slider
under the timeline, its header has the play buttons and the timeline's own
playback bar is hidden; hide the slider and the bar comes back.

Version 0.9.27 fixes Graph **Focus** when animation-layer Influence curves
are visible. Focus now distinguishes Action keys, NLA strip influence and
drivers, and restores their previous visibility when toggled off. It also
recovers old partial Focus records left by the object/layers exception.

Version 0.9.26 routes **Ctrl+Tab** through Motion Room's timeline tabs.
Hover the timeline and press Ctrl+Tab to switch Graph / Blender Timeline;
from Motion or Clip, it opens Graph. Tab buttons and animation mode stay in
sync, while panel sizes, the viewport and the Time Slider stay in place.
Outside Motion Room, Blender keeps its normal shortcut behavior. Animation
layer selection is unchanged: the circle chooses the layer to edit, not an
on/off checkbox; select another layer or Base Animation to change it.

Version 0.9.25 replaces box/bone Ghosts with **Onion Skin**: translucent,
evaluated mesh poses, including armature deformation and shape keys. Open
**Onion Skin** on the timeline ribbon. Enable Show Previous and/or Show Ahead,
choose each count and color, and adjust Opacity. More distant poses fade more.
Keys is the default; Frames supports a fixed step. Wireframe uses original
mesh edges, without triangulation diagonals, and has adjustable width.

Snapshots and GPU batches are cached. Appearance changes do not reevaluate
rigs. Sampling pauses during playback and editing; previews hide during
playback. The per-pose geometry limit skips oversized meshes with an explanation
in the settings. Raising it costs memory and drawing speed. Initial evaluation
of a heavy rig can still cause a pause: sampling yields between frames, but
Blender cannot interrupt an individual deformation evaluation.

Version 0.9.24 adds Maya's **Time Slider and Range Slider**: a strip across
the bottom of Motion Room (Window > Time Slider turns it off and on). The
Clip, Motion, Graph and Blender editors stay above it.
- Red ticks show the selected controls' keys (green: breakdowns; on an
  animation layer, the active layer's keys). Click or drag to scrub;
  middle-drag moves time but keeps the pose, so S, M or I keys it there.
- Shift+drag selects a red range: drag its middle to move those keys, an end
  to scale them (Esc puts them back); double-click selects the whole range.
- Right-click: Cut, Copy, Paste, Paste Insert, Delete, Snap, Tangents (Auto,
  Spline, Linear, Flat, Stepped), Set Key, Set Breakdown. They act on the red
  range, or at the playhead when there is none.
- The Range Slider's bar is the playback range (Blender's preview range)
  inside the animation range: drag it, or its ends; double-click shows the
  whole animation again. The header has the playback buttons, the current
  frame and both ranges.
- **Maya Keys** (header switch, off by default): . and , next and previous
  key, Alt+. and Alt+, next and previous frame, K + drag scrubs anywhere, S
  sets a key (instead of Blender's scale).
- The Maya tools (Layers, Tween, Onion Skin, Driven Key) are now drop-down
  buttons on the Timeline ribbon.

Version 0.9.23 adds Maya-style **animation layers** (the Layers button on
the Timeline ribbon). Layers are scene-wide; each row has a
radio button for the layer keys go to, its name, Additive or Override, a
weight slider, Mute, Solo and Lock. Base Animation is at the bottom.
- Additive (offsets, extra turns, scale factors) or Override (replaces the
  layers below at its weight). Add makes a layer from the selected models;
  Add/Remove Selected changes who is in it.
- Every Motion Room edit works on the active layer and lands the result you
  see exactly where you put it: Move/Rotate/Screen drags, time-selection
  edits and presets, Auto Key, M/I, motion-path tangents, at any weight.
  Graph Editor and Dope Sheet show the active layer's own keys, as in Maya.
- Merge Down bakes a layer into the one below, keyed where either has keys,
  keeping the pose; merging the last one gives the model its plain Action
  back. Extract Selected moves the selected controls' keys to a new layer.
- Layers are Blender NLA tracks, so the file plays the same without the
  add-on. Hand-made NLA on a model is left alone (it cannot join layers), and
  edits under a full-weight Override layer are refused with the reason.

Version 0.9.22 adds four Maya animator tools (drop-down buttons on the
Timeline ribbon: Layers, Tween, Onion Skin, Driven Key; also panels in the
viewport sidebar's Motion Room tab):
- **Tween** (Maya's Tween Machine): keys the selected controls at the
  playhead between each channel's previous and next key. Click 0/25/50/75/100,
  or press the Tween bar, move left/right (Ctrl: 10% steps, past either end
  overshoots) and click; Esc puts the keys back.
- **Buffer curves** (Graph Editor header, Buffer): a faint copy of each shown
  curve from before you edited it; Snapshot takes a new copy, Swap exchanges
  the curve and its copy.
- **Onion Skin**: cached translucent mesh poses before and/or after the
  playhead, with counts, colors, opacity, fading and original-edge wireframe.
  Selecting a rig includes its visible skinned or parented meshes.
- **Set Driven Key**: Load Driver (one channel of the active control), Load
  Driven (the other selected controls), then pose: driver value, driven pose,
  Key, repeat; Done turns the drivers on, drops channels that never changed
  and leaves no keys from posing.

Also fixed: viewport I inserts Motion Room keys again (0.9.20's shortcut
sync had turned it into a second M).

Version 0.9.21: picking another curve in the Graph Editor's channel list
deselects the old curve's keys, so the middle mouse moves only what you
picked; holding Ctrl also hides Blender's Move/Rotate handles, so Ctrl+click
always reaches the bone under them (not during a drag, where Ctrl snaps).

Version 0.9.20 gives Motion Room its own section in Preferences > Keymap
(Window > Shortcuts... opens it): every Motion Room hotkey, grouped by editor,
remappable with Shift/Ctrl/Alt combinations, switchable off and restorable,
like any Blender shortcut. The work-camera flight keys are in it too: while the
left mouse button is held, E and Z fly up, Q and X fly down (add or change
keys there). Outside a flight Q and E still pick the Select and Rotate tools.

Version 0.9.19 is the add-on's new name, Motion Room, with its logo (in the
Window menu and the add-on preferences). The tab, menus, settings and files
are renamed; a file saved with the old "Source Animation" tab opens with it
renamed. The extension id stays `sfm_motion_workshop`, so installing this
version updates an existing install and keeps its settings.

Version 0.9.18 zooms the Timeline around the mouse pointer: Shift + wheel in
steps of 15% of the time shown, Ctrl + wheel in fine 4% steps for accurate
framing (in the Graph Editor the wheel zooms time and Ctrl + wheel the values,
also around the mouse).

Version 0.9.17 keeps rigs with constraints light on big maps: their motion
paths are evaluated with only the rig (and what it depends on), not the whole
map, and selecting a bone no longer rebuilds the Animation Set list.

Version 0.9.16 makes W and E Blender's own Move and Rotate tools (select
through them as in Layout; Tab's Local/Global stays when you switch tools).
**W/E Handles: Source** behind the viewport gear brings back the SFM handles
(joint and surface snapping, depth moves, free rotate). While the Motion Editor
plays, the SFM handles stand in so a drag still records. Big scenes run much
lighter: an idle Motion Room tab no longer re-evaluates the scene to draw a motion
path (plain keyed controls are computed from their keys), and per-frame work
during playback is about a third of what it was.

Version 0.9.15 makes Inherit Rotation switches about seven times faster and
leaves the keys before and after the switched stretch exactly as keyed. A click
through a scene camera (selecting bones or models) stays in the camera view;
only a click-drag leaves it to fly. Holding Ctrl hides the manipulators so
Ctrl+click reaches what is behind them, and a click inside the rotate sphere
selects what is under it. Window > Shortcuts... (also behind the viewport gear)
lists every Motion Room shortcut in Blender's keymap editor to change or restore.

Version 0.9.14 adds editable Maya-style motion trails (drag keys, tangent
handles and timing beads on the path; trail settings behind the gear beside
Motion Paths) and a keyed Inherit Rotation switch that leaves earlier animation
intact. Motion paths are now sampled in short steps while Blender is idle, so a
long shot or heavy character never freezes the viewport.

Version 0.9.13 avoids the temporary native motion-path graph implicated in a
reported Screen/undo crash. Paths now sample the evaluated viewport scene,
restore the exact playhead/subframe, and invalidate their cache on undo/redo.
Screen drags reuse unchanged per-frame spaces instead of reevaluating the
whole selected animation on each mouse event. The first update measures the
range; later mouse updates reuse it. Ctrl+Z now preserves a floating Motion edit in native undo history before
stepping back, so redo can restore it without losing earlier animation.
Screen rotation sensitivity is unchanged.

Version 0.9.12 keeps the Animation Set Editor assignment when Blender copies
or moves an editor internally. Native copies, swaps, splits and saved layouts
retain their Motion Room Tool panel without choosing its type again. The same fix
also covers Element Viewer and Procedural.

Version 0.9.11 preserves initial property poses. Keying a camera includes its
focal length; other unanimated inputs remember that keyed pose and create their
starting key only when first edited later. Those starting values survive
save/reopen without generating unused curves. A later Graph/Blender Timeline
pose no longer extends backward over the first pose.

Shift + mouse wheel zooms time around the pointer in Graph, Motion and Blender
Timeline. In Motion, Ctrl+Shift+wheel retains falloff adjustment. Clicking a
Graph channel reveals and centers its curve vertically while keeping the time
window. The boxed eye with lashes and spiral pupil is **Focus**, at the left
of the timeline header; it shows only the selected curve and restores previous
visibility when toggled off. Alt+Z: Focus; Alt+X: Hide/show; Alt+C: wrench
enable/disable; Alt+V: Lock/unlock. These shortcuts apply inside the Source
Graph Editor, including its channel list. Property curves use native Blender
F-Curves, editable Bezier handles and the Slow Start, Slow Stop and Slow
Start/Stop buttons. Graph mouse gestures also resolve material/node owners.

Version 0.9.10 adds property keyframing from Blender's native Properties fields.
With Auto Key enabled, editing an animatable value on a selected object records
that property: object colors/visibility, modifier and constraint settings,
camera/light data, camera depth of field, active material values and unlinked
material node inputs. Numeric, checkbox, enum and array channels are supported,
including custom property arrays; only changed array components are keyed.
Graph and Blender Timeline modes key at the playhead. Motion mode uses the
time selection and floating edit; a newly covered property with All Time selected
starts with one key. Existing scalar rig sliders retain their SFM static
default behavior. Auto Key off leaves edits manual; I/M or Key records changed
properties and existing visible curves. Non-animatable fields, references and
driven outputs remain governed by Blender and the existing channel checks.

Version 0.9.9 repairs older UI caches that lost the Animation Set Editor's
window assignment. New Motion Room layouts open with Animation Sets on the left,
the viewport above the timeline on the right. Existing custom splits retain
their sizes; an explicit Collections choice remains saved. Repaired caches
keep a `layout.before-source-repair.blend` backup in the Motion Room UI settings
folder. Incomplete layout setup cannot replace your last good saved UI.

Extract `Motion_Room_Project-0.9.40.zip` and run `Start_Demo.cmd`. It
launches a separate Blender session with this checkout's add-on and opens the
demo in the Motion Room tab. It installs nothing and saves no preferences.
The launcher respects an existing `SFM_BLENDER` executable path, then looks in
the usual blender.org install folder, Steam's standard library, Microsoft Store's
launcher and PATH. For a portable copy or a custom Steam library, set
`SFM_BLENDER` to its full executable path, or enter the path if prompted.
You can also run any supported Blender executable with
`--factory-startup --python examples/open_demo.py` (before 5.2 the demo scene
is built fresh, because the saved demo is a 5.2 file).

To install:
- **Blender 4.2 and later:** Edit > Preferences > Get Extensions > Install
  from Disk, choose `motion_room-0.9.40.zip` without unzipping it and
  enable it. It upgrades
  earlier versions in place (same extension id).
- **Blender 4.0 and 4.1** (before extensions existed): Edit > Preferences >
  Add-ons > Install, choose `motion_room-0.9.40-legacy-addon.zip` and
  enable **Motion Room**.

These instructions apply to **Steam, Microsoft Store, blender.org installer
and portable builds** of supported Blender versions. The extension is the same;
choose the ZIP for your Blender version, not its download source. The full
`Motion_Room_Project` archive is for the demo and source code, not Blender's
extension installer.
Each Blender version or separate user profile may need its own installation.
Steam and Store copies of the same version can share settings, so close other
Blender sessions while installing or updating the add-on.

Enabling the add-on adds a **Motion Room** workspace tab without switching
away from your current tab. Its initial windows are arranged when you first
select it. Existing Motion Room layouts are preserved when opening saved files.
The add-on also adds its tab when you open a file that does not have one.
Turn this off with **Add the Motion Room tab** in the add-on's preferences.
You can always use **Window > Open Motion Room** to open it manually.
Motion Room remembers its tab position and each viewport's toolbar/sidebar visibility,
including changes made just before switching tabs or quitting. New files use
your latest arrangement; saved projects keep their own saved workspace layout.
The add-on does not save your startup file automatically.

If installation reports **Failed to extract / WinError 183**, close all Blender
sessions and retry once in a single Blender window using the extension ZIP.
Blender extracts extensions into a temporary folder ending in `@`; an extraction
error by itself does not prove that an old folder caused it. If it repeats,
keep the complete error and affected path for diagnosis. Do not delete the
whole extensions repository or Blender settings to troubleshoot it.

## Blender versions

The same code runs from 4.0 to 5.2. Everything Blender changed in between is
handled in `sfm_blender/compat.py`:
- Action slots (4.4+), and Actions without slots before that
- pose-bone selection (5.0+)
- the Sequencer's strip API and workspace sequencer scene (5.0+)
- bone-collection hierarchy (4.1+)

A few behaviors differ on older versions:
- **Before 4.2**, Blender cannot report that a tool such as G is still
  running. The add-on treats a move as finished after 0.4 s without motion, so
  pausing mid-drag can split one move into two steps of the same floating edit.
  The combined result is the same.
- **Before 4.4**, a slider's Action is checked as a whole: an Action shared by
  two objects is refused, where 4.4+ checks the object's own slot.
- **Before 5.0**, a workspace has no sequencer scene of its own. The Source
  tab remembers the sequence scene, but after switching to a shot the Clip
  Editor shows that shot scene's own Sequencer; Up/Down still switch shots.

In a Motion Room viewport, **Tab switches Local/Global axes** and keeps Object or
Pose mode. Tab over the Timeline retains its editor-switch shortcut; other
workspaces keep Blender's normal Tab behavior. The transform dropdown and
native Scale tool use the same axes after this shortcut.

**M or I inserts a key** at the playhead in Motion, Graph and Blender Timeline,
also with the mouse over a Motion Room viewport. **Auto Key** and **Motion Paths**
buttons are on the ribbon between the viewport and timeline in all three.
Auto Key defaults on. Its on/off choice is shared across these editors and
survives mode changes, new files and restarts. Saved projects retain their own
choice. Off: pose using native tools, SFM handles, sliders or camera flight,
then press M or I to record the pose. No automatic pose keys or temporary
animation curves are written while it is off. Explicit presets/filters and
recording commands remain deliberate animation edits.

Source
can create missing transform channels even with Blender's default Only Insert
Available preference; explicit keying sets and Replace-only keep native rules.
A first pose seeds one constant key at the playhead, without matching setup
keys at the shot's end. Motion range edits still generate the samples needed
to preserve the movement inside and outside the chosen range.

## The animation loop

1. **Select** controls: click a model in a viewport, as in Blender (Shift+click
   adds or removes, clicking empty space deselects). Ctrl+click or Ctrl+drag
   picks bones (hold Ctrl to see them), or click rows in the Animation Set
   Editor. A click selects only when you release quickly without dragging or
   flying; holding LMB still flies the work camera. There are no Object/Pose
   modes to switch. Controls become ready the first time you pose them; there
   is no per-control Create Animation Set step.
2. **Choose time** in the Motion Editor. It starts at All Time (zigzag handles at
   both edges). Shift-drag selects a hard-edged range. Hold Shift through
   drag, release, drag to add falloffs (both of Valve's documented sequences
   work). Ctrl+Shift+wheel adjusts the falloffs, and Shift+right-drag resets
   the nearest one. Drag a hard edge outward to pull out a falloff. Drag an
   infinite handle inward to limit that side only (the other side stays
   infinite), or drag a bound to the editor edge to make it infinite again.
   Alt-drag inside moves the selection; Alt-drag an outer edge scales it.
   Ctrl+A is All Time. Keys 1-4 set the hovered falloff to Linear, Dome, Spike
   or Bell.
3. **Pose** with the manipulators: Q Select, W Move, E Rotate, R Screen, as in
   SFM (in the Motion Room tab's viewports; Edit Mode keeps Blender's keys).
   **Motion paths:** the selected control (up to 8 at once) shows its path
   through time as in SFM: a thin line, a green circle at each of its
   keyframes and a larger circle where it is now. It hides as soon as you
   deselect, follows each edit after you release, and can be turned off with
   Motion Paths behind the gear in the viewport header. Positions come from
   Blender's evaluated scene at each frame, sampled in short steps while
   Blender is idle (the previous path stays until the new one is ready), so a
   long shot or a heavy character never freezes the viewport. Nothing is left
   in the file; a control that already shows a Blender motion path of yours
   is left alone.
   - W and E are Blender's own Move and Rotate tools and handles (the
     default): they select through like Blender's, and what they move follows
     the Motion Room rules (a floating edit through the time selection in Motion
     mode, a key at the playhead in Graph mode). Tab switches Local/Global and
     the choice stays when you change tools; Shift+W / Shift+E or Shift+click
     a manipulator button aligns to the world. While the Motion Editor plays,
     the SFM Move/Rotate handles stand in for Blender's so a drag records
     (puppeteering). A key clicked on a motion path moves alone.
   - **W/E Handles: Source** (behind the viewport gear) brings back the Source
     handles for W and E. Move: arrows, plane squares, and the centre moves in
     the screen plane; on the centre, Shift slides on surfaces, Ctrl snaps to
     nearby joints and Alt moves in depth. Rotate: axis rings, the outer ring
     turns around the view, and dragging inside free-rotates. Press a handle
     and Space to record.
   - Screen (R): centre move (Shift slides on surfaces, Ctrl snaps to nearby
     joints, Alt moves in depth, as on SFM's centre handle), view ring, free
     rotate between them, and a pivot bump. Drag the bump to rotate around another point; double-click it to
     snap it back. A click inside the sphere selects what is under it; Ctrl
     hides the handles so Ctrl+click reaches what is behind them.
   - The left toolbar keeps Blender's tools in native groups (with Source
     W/E handles, Blender's Move and Rotate buttons are left out). Blender's
     G/R/S and typed values follow the same animation rules. Scale stays
     native and the SFM handles step aside for it. Other workspaces and
     Edit/Sculpt/Paint modes retain Blender's full toolbar.
   - The SFM handles and viewport buttons show no hover popups.
4. **Inspect** the weighted result. The selection turns orange while the edit
   floats. You can keep adjusting falloffs, moving or scaling the selection,
   changing the Offset/Overwrite/Transform mode or the preset Strength: the
   edit re-evaluates from the original keys. You can play, pause or scrub and
   pose again at the new frame; dragging never returns the playhead to the
   floating edit's original frame.
5. **Accept** with Enter, or **discard** with Esc. Right-click or Esc during a
   drag cancels only that drag. Shift-drawing a new range, selecting another
   control, switching Timeline mode or saving accepts the edit where it is.
   After Enter, one Ctrl+Z returns to the keys from before the edit.

**Graph mode** (third Timeline icon), as in SFM's Graph Editor:
- Viewport moves key the playhead with the Keymode (Spline, Linear, Step) and
  commit on release.
- **M** keys every *visible* curve of the selected controls and adds a
  **Graph marker** (◆) that owns those keys.
- The **Key** button keys the same channels without a marker. Hide a curve in
  the Graph Editor to leave it out.
- A control with no animation gets its first position and rotation keys.
- A SFM manipulator also creates its first Graph key on release.
- Advancing the playhead and posing again keys that new frame, even after a
  floating preset or a quick switch between controls.
- Key and M skip active driver outputs and check every writable destination
  first, then write all keys or none. A slot shared with another object, NLA,
  linked or muted channels is refused.

**Why Motion edits can show many keys:** a finite time selection with falloff
can sample the resulting motion at each frame. This add-on stores those
samples in Blender's ordinary animation curves, so several position/rotation
channels can show keys at the same frame. Repeated moves do not stack duplicate
times within a channel. A constant All Time offset preserves existing sparse
keys; use Graph mode when authoring individual pose keys at chosen frames.

The Graph gestures, selection staying Blender's click and box select:

| Input | What it does |
|---|---|
| Middle drag | moves selected keys, or a selected tangent handle |
| Ctrl + right drag | scales keys around the pointer |
| Alt + middle drag | pans |
| Wheel | zooms time |
| Ctrl + wheel | zooms values |
| Left drag on a Graph marker (bottom strip) | moves exactly the keys it owns |
| Click a key arrow (top strip) | selects every key at that time (Shift adds) |
| Left drag on a key arrow | moves those keys in whole frames |

**Key arrows:** as in SFM, a blue arrow along the top of the Graph Editor marks
every time that has keys on the visible curves. The arrow at the playhead is
lighter and an arrow whose keys are all selected is highlighted.

Motion bookmarks own no keys. **Offset** in the Graph header keeps the motion
detail between keyframes while you move them; with it off, the curve between
the moved keyframes flattens, as Valve documents. Tangent buttons set Flat,
Linear, Spline, Step, Unified or Broken.

**Clip mode** shows shots in Blender's Sequencer and, as in SFM, does not edit
controls: a pose change is put back with a message. The Timeline mode is one
setting per scene, saved with the file, shared by every window and editor.

**Blender Timeline** (fourth Timeline icon, the keyframe diamond) is Blender's
own Timeline for plain keyframes and fine tuning. In this mode the Motion Room tab
steps aside: Blender's G/R/S and the Timeline's keys use Blender's native tools;
M/I and Auto Key use the shared Motion Room controls (auto-key is no longer held off), and a SFM manipulator keys
the playhead as in Graph mode. Presets need the time selection, so they ask
for the Motion or Graph Editor. Switching back to another mode treats unkeyed
tweaks the way Blender's next frame change would: keyed controls return to
their keys, unkeyed controls keep their pose.

**Copy and paste keys:** select keys and press Ctrl+C, move the playhead, then
Ctrl+V, in the Motion Editor, the Graph Editor or the Blender Timeline
(Blender's own copy and paste).

**Motion curves:** the Motion Editor draws the selected controls' curves over
the time selection in SFM's red/green/blue/white. While an edit floats, the
original motion shows faintly underneath.

**Presets:** all 18 SFM presets in the Procedural panel, click or drag. A click
applies the Strength. A drag to the right sets the amount (300 pixels for
100%, Shift for fine steps, Ctrl for 10% steps) and shows it on the button,
in the editor header and in the status bar while you drag. They float until
Enter or Esc. Zero, Half and One apply only to 0-1 sliders (shape
keys and rig sliders); Zero also zeroes transforms, which snaps a locked control
onto its parent. **Resample at Bookmarks** is in the Motion Editor's right-click
menu. Copy then Paste moves motion to a new selection start.

**Controls panel:** sliders for the selected controls:
- rig custom properties
- a mesh's shape keys (faces)
- a camera's focal length and a light's energy and cone

They follow the same rules as every other move. A control with no animation
keeps a new value for All Time, and gets its previous value keyed first for a
finite range.

**Puppeteering:** record during playback with any of SFM's inputs:
- Hold a manipulator handle and press Space, or grab it while playback is running.
- Drag a Controls slider while it plays.
- Fly the scene camera or a piloted light with LMB + WASD while it plays.

Samples follow playback time. The take is one floating edit (Enter keeps,
Esc discards, undo works), weighted by the time selection; frames outside it
don't change. It ends when playback stops, when Space is pressed, or when the
selection changes. Smooth cleans up jitter, as SFM recommends.

**Review:** hold Shift over the Motion Editor to preview time without moving the
playhead. Ctrl+Space plays the current shot once and returns.

**Rigs:**
- Edits map through each control's own channel space, so a world move lands
  where the handle showed, even under moving or rotated parents.
- IK arms are posed through their target and pole. The evaluated hand stays on
  the target.
- A channel a constraint fully replaces is refused before anything changes, and
  the message names the controller to pose. **Select Controller** in the
  Controls panel selects it. Examples: a bone in an IK chain, or Copy Rotation
  in Replace mode.
- Damped Track, Track To, Limit and Child Of locks keep working on top of edits.
  A locked control's manipulator and world moves follow its lock, so a world-X
  move goes along world X even when the lock target is rotated.
- Drivers on constraint influence, visibility, unrelated custom properties or
  ancestors do not by themselves block a control's FK transforms. An active
  driver on an exact transform component makes that output read-only; free
  components can still be animated. **Key**, **M** and automatic channel setup
  skip driven outputs and leave the drivers intact.
- To change a driven output, animate the rig's input control or slider.
  **Select Controller** selects a driver input when one unambiguous selectable
  source can be found; the Controls panel names discoverable sources. Arbitrary
  driver expressions and constraint chains are not inverted automatically.

**Locks:** the padlock on each Animation Set Editor row locks to the world or to
the active control, with counter-animation; bones too (a world-locked bone is
freed from its parent bone until unlocked). Playhead, Zero and Default make it
follow. Unlock bakes the result without a visible jump.

**Control groups:** armatures list their bone collections as groups (Body,
Arms, Fingers, Legs, Face...). Clicking a group selects every control in it.
The group button in the Animation Set Editor sorts a rig's bones into SFM's
groups.

**Shots:** a shot is a scene strip in the Motion Room workspace's Clip Editor
sequence. It shows its own scene, which holds its animation sets and their
animation, with its own camera and time window. Moving or trimming a shot
never changes its animation, duplicating gives the copy its own animation, and
Up/Down switch shots. Shot time scaling and SFM's roll/ripple modifier drags
are not implemented.

**Work camera:** hold LMB and drag to look, WASD/Z/X to fly, Shift builds speed,
Ctrl slows, wheel zooms. While holding LMB, **hold R and drag horizontally to
roll**. Release R to resume normal look; the rolled horizon is preserved when
you release LMB and on later flights. R is handled only during that flight.
Esc restores its starting view or piloted object. Alt+LMB/MMB/RMB orbit, pan
and dolly. The camera switcher, a dropdown naming the active camera in the
viewport's header as in SFM, looks through scene cameras or pilots a light; the
gear beside it holds the fly speed, smoothing and look sensitivity. It sits
outside the view, so it never catches a click meant for flying. Picking a camera
there also selects it, so holding LMB right away flies the camera itself (a
piloted light flies without being selected). Flying a selected scene camera or a piloted light records into it,
including roll. The held-R
gesture follows Valve's [camera navigation documentation](https://developer.valvesoftware.com/wiki/Source_Filmmaker/Docs/Navigating_with_the_camera);
drag direction and sensitivity are implementation choices.

**Auto-key:** while a Motion Room tab shows a scene in the Clip, Motion or Graph
Editor mode, Blender's auto-key is held off for that scene (the Blender
Timeline mode uses Blender's own auto-key). With Motion Room Auto Key on, the tab records every move itself, so results never depend on
auto-key. The setting returns when you leave the tab, is saved with your own
value, and is restored after a crash.

## What is refused, and why

Each refusal happens before any key changes and says how to fix it:
- edits that would change an active driver's exact output channel (animate
  the rig input instead; free channels remain available)
- muted channels
- F-Curve modifiers or sampled points (editing their result would apply the
  modifier twice)
- an active NLA track, or tweak mode
- non-Replace Action blending
- an Action slot shared with another data-block
- linked or library-overridden data
- axis-angle rotation
- an operation that changes nothing because every channel it would change is
  locked, or is the location of a connected bone (with several controls
  selected, locked channels and connected bones simply stay put, as with
  Blender's own tools, and the rest move)
- a first key, created channel or scale key into a slot another data-block
  shares (the same rules as every other edit)
- a channel fully replaced by a constraint (see Rigs)

A refusal restores the pose; it never keys one frame in place of the requested
range edit.

## Big rigs (Rigify, Auto-Rig Pro and others)

- **Hidden controls.** Rigs keep FK, tweak and other controls in bone
  collections that are often hidden. Picking such a bone in the Animation Set
  Editor shows it (and its collection), and selecting a hidden control group
  shows the group, since Blender cannot pose hidden bones. Group rows have an
  eye button to show or hide a collection.
- **IK/FK switches.** The Controls panel lists the rig's IK/FK switches
  (0-1 properties named for IK or FK, not limb options like stretch or pole:
  Rigify's `IK_FK`, Auto-Rig Pro's `ik_fk_switch`, CloudRig's `ik_arm_left`)
  with a key button, wherever on the rig they live.
- **Parent switching.** A control under an Armature constraint (CloudRig's
  parent switching) is animated like any other; world-space moves map through
  the constraint as through a parent.
- **Any other constraint setup.** Where a control's constraints change how its
  channels move it (Action, Transformation, offset or mixed Copy constraints
  and more), the add-on measures it: nudge, let Blender evaluate the rig, read
  back where it went. Moves then go where Blender shows them, on any rig.
- **Tested rigs.** Every Rigify template, generated and plain, an
  FBX-import-style skeleton, and Blender Studio's Snow, Rain and Default Cube
  (see VALIDATION.md).
- **The rig's own panel.** Rigify adds a panel (IK/FK snapping, layer buttons)
  from a script inside the file. Blender blocks it in files from elsewhere
  until you click **Allow Execution** in its warning bar; the Controls panel
  says so when that happened. The add-on never changes that security setting.
- **Speed.** With a 700-bone Rigify rig selected the add-on uses about 0.2% of
  Blender's time while idle, playback runs at Blender's own speed, and a
  world-space Motion drag of the whole rig takes about 1.4 s per mouse move
  (most edits touch a few controls and are far faster). See VALIDATION.md.

## Customize and save the UI

Split, join and resize areas with Blender's normal borders. Window > Layouts
rebuilds one of SFM's five arrangements after asking. The Window menu lists
every Motion Room window, with Blender's own entries in its Blender submenu. Ctrl+S
saves the layout in the .blend. Your custom Motion Room arrangement is also saved
automatically: new projects and later sessions reuse its window sizes, splits,
editor choices, overlays and sidebar settings. A project with a saved Source
tab keeps its own arrangement. The add-on never changes startup.blend itself
or puts your scene, characters or animation into the UI template.

Your Motion Room settings follow you to new files and later sessions, saved
automatically even with Blender's Auto-Save Preferences disabled: work-camera speed, smoothing and look
sensitivity, Bone Display, Global/Local space, Keymode, Show Time Selection,
Motion Paths, Blender Tools Follow SFM Rules and the last layout chosen in Window > Layouts.
The active manipulator, Timeline mode, Offset/Overwrite/Transform and Graph
Offset mode are remembered too, so the restored editor and animation behavior agree.
A file you saved keeps its own values. Turning Bones on or off in the viewport's
Overlays menu stays as you set it (it switches Bone Display between Always and
Hold Ctrl).

Click **Got it, hide the guide** once. The acknowledgement follows you across
projects, layouts and restarts. Window > SFM Quick Guide opens it again when
you want it. These UI defaults are kept in `source_animation` inside Blender's
version-specific configuration folder; Steam, Store and regular installs use
the same mechanism.

## Native builds and large scenes

Large Animation Set Editors use Blender's native scrolling list. Only visible
rows draw widgets; a runtime scene index avoids rebuilding the complete map on
ordinary viewport movement. Search, hierarchy, collapse, selection and visibility
remain available. Small scenes retain their existing layout.

An optional Windows x64 C++ backend accelerates batch falloff math. UI and Blender
data access stay in Python, with a fallback when the native library is unavailable.
It requires no compiler or Python-package installation for users.

Readable source stays in `sfm_blender/` and `native/`. Build/obfuscated copies and
compiled files go in `build/`, and installable ZIPs go in `dist/`. Build with
`python tools/build_release.py --native --obfuscate`. All installers include
matching readable GPL source. Obfuscation is reversible, not copy protection.
See [BUILDING.md](BUILDING.md) for supported platforms, folder structure and tests.

## Development

- `python tools/run_ui_persistence_test.py --blender "C:/path/blender.exe"`
  checks the saved UI, preferences and one-time guide across four actual
  Blender launches with isolated settings and preference auto-save disabled.
  It also exercises mixed window/Timeline/manipulator button routes. These
  are API/lifecycle checks; simulated mouse and keyboard cases run separately.
- `python tools/run_all_tests.py` runs the unit tests, every Blender suite and
  the package check with crash detection, then prints a summary. Suites run
  side by side (about 3 minutes; `SFM_TEST_JOBS` sets how many, `--serial`
  runs one at a time); anything that fails is run again on its own to decide.
- `python tools/run_versions.py` runs that on every Blender it finds (the
  builds in `work/blender_versions`, Steam, Microsoft Store) side by side,
  each in its own `work/versions/<name>` folder: about 14 minutes for seven.
- `tests/blender_animation_loop.py` drives the whole loop through simulated
  input events. It finds manipulator handles by asking Blender which gizmo is
  highlighted under the mouse, then presses there.
- `python tools/check_crashes.py` lists Blender crash logs.
- `python tools/probe_extension_install.py --blender "C:/path/blender.exe"
  --archive dist/motion_room-0.9.40.zip --label my-blender` installs,
  reinstalls and reloads the actual extension in isolated user folders. It
  verifies installed bytes and registration without touching your settings.
  This background check does not verify workspace tabs or mouse input.
- `python tools/build_release.py` builds `dist/motion_room-<version>.zip`
  and `dist/Motion_Room_Project-<version>.zip`. The package test checks
  that every packaged module is byte-identical to the tested source.

Modules: `edit.py` owns the floating edit (baseline, operations, gestures);
`motion.py` is the engine; `manip.py` is the handle geometry; `range_math.py`
the time selection; `workflow.py` the manipulators, Timeline mode and the
Blender-tool adapter; `motion_ui.py` the Motion Editor gestures; `rig.py`
constraint rules.

Licensed GPL-3.0-or-later; see LICENSE. No Valve code or assets are included.
